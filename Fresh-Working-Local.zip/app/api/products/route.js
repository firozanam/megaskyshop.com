import { NextResponse } from 'next/server';
import { getDatabase } from '@/lib/mongodb';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';

const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;

async function connectWithRetry(retries = MAX_RETRIES) {
    try {
        const db = await getDatabase();
        if (!db) throw new Error('Database connection failed');
        return db;
    } catch (error) {
        if (retries > 0) {
            console.log(`Retrying database connection... (${retries} attempts left)`);
            await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
            return connectWithRetry(retries - 1);
        }
        throw error;
    }
}

export async function GET() {
    try {
        const db = await connectWithRetry();
        const products = await db.collection('products')
            .find({})
            .project({
                name: 1,
                price: 1,
                description: 1,
                category: 1,
                stock: 1,
                image: 1,
                avgRating: 1
            })
            .toArray();

        return NextResponse.json({ products });
    } catch (error) {
        console.error('Error fetching products:', error);
        return NextResponse.json({ 
            error: 'Failed to fetch products',
            message: process.env.NODE_ENV === 'development' ? error.message : undefined
        }, { 
            status: error.name === 'MongoNetworkError' ? 503 : 500 
        });
    }
}

export async function POST(request) {
    try {
        const session = await getServerSession(authOptions);
        if (!session || !session.user.isAdmin) {
            return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
        }

        const db = await connectWithRetry();
        const data = await request.json();
        const { name, price, description, category, stock, image } = data;

        // Validate the incoming data
        const validationErrors = [];
        if (!name) validationErrors.push('Name is required');
        if (!price || isNaN(parseFloat(price))) validationErrors.push('Valid price is required');
        if (!description) validationErrors.push('Description is required');
        if (!category) validationErrors.push('Category is required');
        if (!stock || isNaN(parseInt(stock))) validationErrors.push('Valid stock quantity is required');

        if (validationErrors.length > 0) {
            return NextResponse.json({ 
                error: 'Validation failed', 
                details: validationErrors 
            }, { 
                status: 400 
            });
        }

        const newProduct = {
            name,
            price: parseFloat(price),
            description,
            category,
            stock: parseInt(stock),
            image,
            reviews: [],
            avgRating: 0,
            createdAt: new Date(),
            updatedAt: new Date()
        };

        const result = await db.collection('products').insertOne(newProduct);

        return NextResponse.json({ 
            message: 'Product created successfully', 
            productId: result.insertedId 
        });
    } catch (error) {
        console.error('Failed to create product:', error);
        return NextResponse.json({ 
            error: 'Failed to create product',
            message: process.env.NODE_ENV === 'development' ? error.message : undefined
        }, { 
            status: error.name === 'MongoNetworkError' ? 503 : 500 
        });
    }
}

export async function PUT(request) {
    try {
        const session = await getServerSession(authOptions);
        if (!session || !session.user.isAdmin) {
            return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
        }

        const db = await connectWithRetry();
        const formData = await request.formData();
        const id = formData.get('id');
        const name = formData.get('name');
        const price = formData.get('price');
        const description = formData.get('description');
        const category = formData.get('category');
        const stock = formData.get('stock');
        const image = formData.get('image');

        const updateData = {
            name,
            price: parseFloat(price),
            description,
            category,
            stock: parseInt(stock, 10)
        };

        if (image && image.size > 0) {
            const bytes = await image.arrayBuffer();
            const buffer = Buffer.from(bytes);

            const uniqueFilename = `${uuidv4()}${path.extname(image.name)}`;
            const imagePath = path.join(process.cwd(), 'public', 'images', uniqueFilename);

            await writeFile(imagePath, buffer);
            updateData.image = `/images/${uniqueFilename}`;
        }

        const result = await db.collection('products').updateOne(
            { _id: new ObjectId(id) },
            { $set: updateData }
        );

        if (result.matchedCount === 0) {
            return NextResponse.json({ error: 'Product not found' }, { status: 404 });
        }

        return NextResponse.json({ message: 'Product updated successfully' });
    } catch (error) {
        console.error('Failed to update product:', error);
        return NextResponse.json({ 
            error: 'Failed to update product',
            message: process.env.NODE_ENV === 'development' ? error.message : undefined
        }, { 
            status: error.name === 'MongoNetworkError' ? 503 : 500 
        });
    }
}

export async function DELETE(request) {
    try {
        const { id } = await request.json();
        const db = await connectWithRetry();
        const result = await db.collection('products').deleteOne({ _id: new ObjectId(id) });
        if (result.deletedCount === 0) {
            return NextResponse.json({ error: 'Product not found' }, { status: 404 });
        }
        return NextResponse.json({ message: 'Product deleted successfully' });
    } catch (error) {
        console.error('Failed to delete product:', error);
        return NextResponse.json({ 
            error: 'Failed to delete product',
            message: process.env.NODE_ENV === 'development' ? error.message : undefined
        }, { 
            status: error.name === 'MongoNetworkError' ? 503 : 500 
        });
    }
}
