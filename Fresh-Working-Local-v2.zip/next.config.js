/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        remotePatterns: [
            {
                protocol: 'https',
                hostname: '9iuwrme1pfmpwt7q.public.blob.vercel-storage.com'
            },
            {
                protocol: 'https',
                hostname: 'blob.vercel-storage.com'
            },
            {
                protocol: 'https',
                hostname: 'miro.medium.com'
            },
            {
                protocol: 'http',
                hostname: 'localhost',
                port: '3000',
                pathname: '/**'
            },
            {
                protocol: 'http',
                hostname: '127.0.0.1',
                port: '3000',
                pathname: '/**'
            },
            {
                protocol: 'https',
                hostname: 'steadfast.com.bd',
                pathname: '/assets/**'
            },
            {
                protocol: 'https',
                hostname: 'megaskyshop.com',
                pathname: '/**'
            }
        ]
    },
    env: {
        BLOB_READ_WRITE_TOKEN: process.env.BLOB_READ_WRITE_TOKEN,
        NEXT_PUBLIC_BASE_URL: process.env.NEXTAUTH_URL || 'http://localhost:3000'
    },
    poweredByHeader: false,
    compress: true,
    optimizeFonts: true,
    swcMinify: true,
    reactStrictMode: true,
    experimental: {
        optimizeCss: false, // Disable experimental CSS optimization
        scrollRestoration: true
    },
    webpack: (config, { isServer, dev }) => {
        // Client-side configuration
        if (!isServer) {
            config.optimization = {
                ...config.optimization,
                splitChunks: {
                    chunks: 'all',
                    minSize: 20000,
                    maxSize: 244000,
                    minChunks: 1,
                    maxAsyncRequests: 30,
                    maxInitialRequests: 30,
                    cacheGroups: {
                        defaultVendors: {
                            test: /[\\/]node_modules[\\/]/,
                            priority: -10,
                            reuseExistingChunk: true,
                            name: 'vendors'
                        },
                        default: {
                            minChunks: 2,
                            priority: -20,
                            reuseExistingChunk: true,
                        },
                    },
                },
                runtimeChunk: 'single'
            };
        }

        // Enable source maps in development
        if (dev) {
            config.devtool = 'eval-source-map';
        }

        return config;
    }
};

module.exports = nextConfig;
