module.exports = {
  extends: ['next/core-web-vitals'],
  rules: {
    'react/no-unescaped-entities': 'off',
    'import/no-anonymous-default-export': 'off',
  },
}
