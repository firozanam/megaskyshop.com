import { useState, useCallback, useEffect } from 'react'

export function useForceUpdate() {
  const [, setTick] = useState(0)
  const update = useCallback(() => {
    setTick(tick => tick + 1)
  }, [])
  return update
}

export function useCartUpdate(cart) {
  const forceUpdate = useForceUpdate()
  
  useEffect(() => {
    forceUpdate()
  }, [cart, forceUpdate])
}
